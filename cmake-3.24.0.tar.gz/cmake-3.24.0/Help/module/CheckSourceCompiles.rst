.. cmake-module:: ../../Modules/CheckSourceCompiles.cmake
